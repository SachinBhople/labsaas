Super Admin (1 - M ) 

Admin (1 - M) labs (1 - M) employee 

Website Refrance:

https://www.lalpathlabs.com
https://www.metropolisindia.com
https://www.lupindiagnostics.com
https://www.suburbandiagnostics.com
https://www.apollodiagnostics.in
https://www.thyrocare.com
https://agilusdiagnostics.com
https://www.detectdiagnostics.com